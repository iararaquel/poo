package br.com.exemplo.eleicao.entidades;

public class Eleitor {
    private String nome;

    public Eleitor(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
